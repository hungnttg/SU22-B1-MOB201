package com.example.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.R;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Demo51Main2Activity extends AppCompatActivity {
    ListView listView;
    List<String> lsTitle = new ArrayList<>();//chứa title
    List<String> lsLink = new ArrayList<>();//chứa link
    ArrayAdapter<String> arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main2);
        listView = findViewById(R.id.demo51Lv);
        //gọi AsyncTask
        new TheThao().execute("https://ngoisao.vnexpress.net/rss/the-thao.rss");
        //tạo adapter
        arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,lsTitle);
        listView.setAdapter(arrayAdapter);
        //xử lý sự kiện
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String link = lsLink.get(i);//lấy về Id link
                //chuyển dữ liệu qua Activity khác
                Intent intent = new Intent(Demo51Main2Activity.this,Demo51Kq.class);
                intent.putExtra("linksent",link);
                startActivity(intent);
            }
        });
    }
    private class TheThao extends AsyncTask<String,Void,String>{
        //hàm lấy dữ liệu từ server
        @Override
        protected String doInBackground(String... strings) {
            StringBuilder stringBuilder = new StringBuilder();//bộ chứa dữ liệu đọc ddiwocj
            try {
                URL url = new URL(strings[0]);//lấy đường link truyền vào
                //tạo luồng đọc
                InputStreamReader reader
                        = new InputStreamReader(url.openConnection().getInputStream());
                //sử dụng luồng đệm
                BufferedReader bufferedReader = new BufferedReader(reader);
                //đọc từng dòng dữ liệu
                String line="";
                while ((line = bufferedReader.readLine())!=null)//nếu không phải cuối luồng
                {
                    stringBuilder.append(line);//đưa dòng đọc được vào bộ chứa dữ liệu
                }
                return stringBuilder.toString();//trả về kết quả (dữ liệu thô)

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        //hàm trả dữ liệu về client
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //xử lý dữ liệu thô-> tinh
            XMLPar xmlPar = new XMLPar();
                try {
                    //lấy về dữ liệu thô do doInBackground chuyển đến
                    Document document = xmlPar.getDocument(s);
                    //lấy về các item
                    NodeList nodeList = document.getElementsByTagName("item");
                    //tách link, title
                    String link="";
                    String title="";
                    for(int i=0;i<nodeList.getLength();i++)
                    {
                        //lấy về item và ép kiểu sang element
                        Element element = (Element)nodeList.item(i);
                        //lấy title
                        title = xmlPar.getValue(element,"title");
                        lsTitle.add(title);//đưa vào list
                        //lấy link
                        link = xmlPar.getValue(element,"link");
                        lsLink.add(link);//đưa vào lít
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (SAXException e) {
                    e.printStackTrace();
                }
            }

    }
}
