package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btnStart, btnStop;
    Intent intent1,intent2,intent3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt1 = findViewById(R.id.demo11Txt1);
        txt2 = findViewById(R.id.demo11Txt2);
        btnStart = findViewById(R.id.demo11Btn1);
        btnStop = findViewById(R.id.demo11Btn2);

        intent1 = new Intent(this,Demo11Service1.class);
        intent2 = new Intent(this,Demo12Service.class);
        intent3 = new Intent(this,Demo13Service.class);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startService(intent1);
                /*
                intent2.putExtra("masv",txt1.getText().toString());
                intent2.putExtra("tensv",txt2.getText().toString());
                startService(intent2);
                 */
                //3--------
                //Lay ky tu nhap vao
                String inputChar = txt2.getText().toString();
                char[] c  = inputChar.toCharArray();//chuyen chuoi thanh mang
                //lay chuoi can dem
                String check = txt1.getText().toString();
                //dua vao intent
                intent3.putExtra("char",c[0]);//ky tu can check
                intent3.putExtra("check",check);//chuoi can check
                startService(intent3);
                //end 3----
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //stopService(intent1);
                //stopService(intent2);
                stopService(intent3);
            }
        });

    }
}
