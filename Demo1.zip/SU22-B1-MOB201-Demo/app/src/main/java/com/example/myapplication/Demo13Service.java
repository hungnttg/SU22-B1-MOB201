package com.example.myapplication;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Demo13Service extends IntentService {

    public Demo13Service()
    {
        super("Demo13Service");
    }
    int count = 0;
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        char c1 = intent.getCharExtra("char",'0');
        String check = intent.getStringExtra("check");
        count = demKyTu(check,c1);
    }
    @Override
    public void onDestroy() {
        Toast.makeText(this,"So ky tu la: "+count,Toast.LENGTH_LONG).show();
        Toast.makeText(this,"Service huy tu dong",Toast.LENGTH_LONG).show();
        super.onDestroy();
    }
    public int demKyTu(String str,char c)
    {
        int dem = 0;
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)==c)
            {
                dem++;
            }
        }
        return dem;
    }
}
