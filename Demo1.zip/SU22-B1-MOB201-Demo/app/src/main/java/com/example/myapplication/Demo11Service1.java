package com.example.myapplication;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Demo11Service1 extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this,"Ham OnCreate duoc goi",Toast.LENGTH_SHORT).show();
        Log.d("OnCreate","Ham OnCreate duoc goi");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this,"Ham onStartCommand duoc goi",Toast.LENGTH_SHORT).show();
        Log.d("onStartCommand","Ham onStartCommand duoc goi");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this,"Ham onDestroy duoc goi",Toast.LENGTH_SHORT).show();
        Log.d("onDestroy","Ham onDestroy duoc goi");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
