package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class Demo31Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        listView = findViewById(R.id.demo31Listview);
        //requestPermission();
        getContacts();
    }
    public boolean requestPermission()
    {
        if(Build.VERSION.SDK_INT>=23)
        {
            if(checkSelfPermission(Manifest.permission.WRITE_CONTACTS)
            ==PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_CONTACTS)
            ==PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS)
            ==PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
            ==PackageManager.PERMISSION_GRANTED)
            {
                return  true;
            }
            else
            {
                ActivityCompat.requestPermissions(Demo31Main2Activity.this,new String[]{
                      Manifest.permission.READ_CONTACTS,
                      Manifest.permission.WRITE_CONTACTS,
                      Manifest.permission.READ_PHONE_NUMBERS,
                      Manifest.permission.READ_PHONE_STATE
                },1);
                return false;
            }
        }
        else
        {
            return true;
        }
    }
    void getContacts()
    {
        //1. xin quyen
        //neu khong co quyen
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            //xin quyen
            ActivityCompat.requestPermissions(this,new String[]{
                    Manifest.permission.READ_CONTACTS
            },999);
        }
        else //neu co quyen, ta doc du lieu
        {
            //2. duong dan
            Uri uri = ContactsContract.Contacts.CONTENT_URI;
            //Uri uri = Uri.parse("content://contacts/people");
            ArrayList list = new ArrayList();//luu contacts
            //2.2. Tao con tro dong
            Cursor cursor
                    =getContentResolver().query(uri,null,null,null,null);
            //2.3. Kiem tra xem danh ba co du lieu khong
            if(cursor.getCount()>0)
            {
                cursor.moveToFirst();//di chuyen ve ban ghi dau tien
                //2.4 - doc du lieu
                while (!cursor.isAfterLast())//neu khong phai ban ghi cuoi cung
                {
                    //2.4.1. lay so thu tu luu trong danh ba
                    String thutu = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    //2.4.2 - Lay ten ban ghi
                    String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    //2.4.3 - doc so dien thoai
                    //2.4.3.1 - tao con tro cot
                    Cursor cursorNumber = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID+" =? AND "+
                                    ContactsContract.CommonDataKinds.Phone.TYPE+"="+
                                    ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,
                            new String[]{thutu},null
                    );
                    String contactNumber = null;
                    //2.4.3.1  lay so mobile
                    if(cursorNumber.moveToFirst())//di chuyen ve cot dau tien
                    {
                        contactNumber= cursorNumber.getString(
                                cursorNumber.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    }
                    cursorNumber.close();
                    ///---------
                    String thuTu_Ten = thutu+" - "+name+ " - "+contactNumber;//ghep chuoi
                    list.add(thuTu_Ten);
                    cursor.moveToNext();
                }
                cursor.close();
                //Dua du lieu len listview
                ArrayAdapter<String>
                        adapter = new ArrayAdapter<>(Demo31Main2Activity.this,
                        android.R.layout.simple_list_item_1,list);
                listView.setAdapter(adapter);
            }
        }

    }
}
