package com.example.myapplication.demo4;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo43Main2Activity extends AppCompatActivity {
    TextView tv1;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_main2);
        tv1 = findViewById(R.id.demo43Tv1);
        Demo43CheckNetwork demo43CheckNetwork
                =new Demo43CheckNetwork(getApplicationContext());
        demo43CheckNetwork.registerNetwork();
        if(Demo43NetworkAvailable.isNetworkConnected)
        {
            tv1.setText("Ban ket noi thanh cong voi internet");
        }
        else
        {
            tv1.setText("Khong ket noi duoc voi internet");
        }
    }
}
