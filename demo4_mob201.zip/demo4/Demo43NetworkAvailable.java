package com.example.myapplication.demo4;

public class Demo43NetworkAvailable {
    public static boolean isNetworkConnected = false;
}
