package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo42Main2Activity extends AppCompatActivity {
    TextView tv1;
    ConnectivityManager connectivityManager;//dich vu quan ly ket noi
    NetworkInfo myWifi, my4g;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo42_main2);
        tv1  =findViewById(R.id.demo42Tv1);
        //khoi tao dich vu quan ly ket noi
        connectivityManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
       //gan ket noi wifi
        myWifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        //gan ket noi 4G
       my4g = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

        if(myWifi.isConnected())
        {
            tv1.setText("Ban dang dung wifi");
        }
        else if(my4g.isConnected())
        {
            tv1.setText("Ban dang dung 4G");
        }
        else
        {
            tv1.setText("Khong ket noi");
        }

    }
}
