package com.example.myapplication.demo4;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

public class Demo43CheckNetwork {
    Context context;

    public Demo43CheckNetwork(Context context) {
        this.context = context;
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void registerNetwork()
    {
        try {
            ConnectivityManager connectivityManager
                    =(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkRequest.Builder builder = new NetworkRequest.Builder();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback(){
                    @Override
                    public void onAvailable(@NonNull Network network) {
                        super.onAvailable(network);
                        Demo43NetworkAvailable.isNetworkConnected=true;
                    }

                    @Override
                    public void onLost(@NonNull Network network) {
                        super.onLost(network);
                        Demo43NetworkAvailable.isNetworkConnected=false;
                    }
                });
            }
        }
        catch (Exception e)
        {
            Demo43NetworkAvailable.isNetworkConnected = false;
        }
    }
}
