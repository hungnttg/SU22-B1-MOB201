package com.example.myapplication.demo4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo41Main2Activity extends AppCompatActivity
implements LocationListener
{
    LocationManager locationManager;//quan ly vi tri
    TextView tv1,tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main2);
        tv1 = findViewById(R.id.demo41Tv1);
        tv2 = findViewById(R.id.demo41Tv2);

        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);//dich vu quan ly vi tri
        //kiem tra quyen
        if(ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED)
        {
            return;
        }
        //ham update vi tri
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,
                1,(LocationListener)this);
    }
    //ham xac dinh su thay doi vi tri
    @Override
    public void onLocationChanged(@NonNull Location location) {
        double longti = location.getLongitude();
        double lati = location.getLatitude();
        tv1.setText("Long: "+String.valueOf(longti));
        tv2.setText("Lat: "+String.valueOf(lati));
    }
}
