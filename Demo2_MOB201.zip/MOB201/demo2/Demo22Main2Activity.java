package com.example.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo22Main2Activity extends AppCompatActivity {
    EditText txt1;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        txt1 = findViewById(R.id.demo22Txt1);
        btn1 = findViewById(R.id.demo22Btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nhận dữ liệu
                String data = txt1.getText().toString();
                //Chuyển cho broadcast
                Intent intent = new Intent(Demo22Main2Activity.this,
                        MyBroadcast2.class);
                intent.putExtra("br",data);
                //broadcast thông báo cho người dùng
                sendBroadcast(intent);
            }
        });
    }
}
