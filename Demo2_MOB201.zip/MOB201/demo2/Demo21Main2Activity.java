package com.example.myapplication.demo2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.myapplication.R;

public class Demo21Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main2);
        RegisterAndroid();
        Intent intent = new Intent(this,MyBroadcast1.class);//điều hướng
        sendBroadcast(intent);//gửi broadcast cho activity
        Toast.makeText(getApplicationContext(),"aa",Toast.LENGTH_LONG).show();
    }
    public boolean RegisterAndroid()
    {
        if(Build.VERSION.SDK_INT>=23)
        {
            //kiểm tra xem có quyền không
            if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==
                    PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS)==
                    PackageManager.PERMISSION_GRANTED)
            {
                return true;//nếu có quyền
            }
            else
            {
                //nếu không có quyền -> xin quyền
                ActivityCompat.requestPermissions(Demo21Main2Activity.this,
                        new String[]{Manifest.permission.READ_PHONE_STATE,
                                     Manifest.permission.READ_PHONE_NUMBERS},1);
                return false;
            }
        }
        else
        {
            Log.d("PHan quyen","Ban da co quyen");
            return true;
        }
    }
}
